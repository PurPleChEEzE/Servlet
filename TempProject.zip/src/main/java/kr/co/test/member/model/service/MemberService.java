package kr.co.test.member.model.service;

import kr.co.test.member.model.dto.MemberDTO;

public interface MemberService {
	public int register(MemberDTO mdto);
	

}
