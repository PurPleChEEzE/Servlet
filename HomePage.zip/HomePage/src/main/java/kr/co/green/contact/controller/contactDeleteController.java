package kr.co.green.contact.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.green.contact.model.service.ContactServiceImpl;

@WebServlet("/contact/delete.do")
public class contactDeleteController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public contactDeleteController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int boardNo = Integer.parseInt(request.getParameter("boardNo"));
		
		ContactServiceImpl contactService = new ContactServiceImpl();
		int result = contactService.setDelete(boardNo);
//		System.out.println(result);
		
		if(result ==1) {
			response.sendRedirect("/contact/list.do?cpage=1");
		}
	}

}
