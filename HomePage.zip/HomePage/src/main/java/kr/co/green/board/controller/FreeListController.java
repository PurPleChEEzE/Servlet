package kr.co.green.board.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import kr.co.green.board.model.dto.FreeDtoImpl;
import kr.co.green.board.model.service.FreeServiceImpl;
import kr.co.green.common.PageInfo;
import kr.co.green.common.Pagination;

/**
 * Servlet implementation class FreeListController
 */
@WebServlet("/freeBoard/list.do")
public class FreeListController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FreeListController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		FreeServiceImpl freeService = new FreeServiceImpl();
		
		int cpage = Integer.parseInt(request.getParameter("cpage"));
		
		String category = request.getParameter("category");
		String searchText = request.getParameter("search-text");
		
		System.out.println(category);
		System.out.println(searchText);

		//전체 게시글 수
		int listCount = freeService.getListCount(category, searchText);
		
		//보여질 페이지 수
		int pageLimit = 5;
		
		//한페이지에 보여질 게시글 수
		int boardLimit = 5;
		
		PageInfo pi = Pagination.getPageInfo(listCount, cpage, pageLimit, boardLimit);
				
		
		//게시글 목록 불러오기
		ArrayList<FreeDtoImpl> list = freeService.getList(pi, category, searchText);
		
		//게시글 번호 구하기
		int row = listCount - (cpage-1)*boardLimit;
//		for (FreeDtoImpl item : list) {
//			System.out.println(item.getBoardTitle());
//		}
		//게시글 목록 jsp에 전달 -> data binding
		request.setAttribute("list", list);
		request.setAttribute("row", row);
		request.setAttribute("pi", pi);
		
		RequestDispatcher view = request.getRequestDispatcher("/views/board/free/freeList.jsp");
		view.forward(request, response);

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
