package kr.co.green.board.model.dto;



public class FreeDtoImpl extends BoardDto{
	
	
}
