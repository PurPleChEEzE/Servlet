package kr.co.green.contact.model.service;

import java.util.ArrayList;

import kr.co.green.board.model.dto.FreeDtoImpl;
import kr.co.green.common.PageInfo;
import kr.co.green.contact.model.dto.ContactDto;

public interface ContactService {
	public int enroll(ContactDto contactDto);

	public int getListCount();

	public ArrayList<ContactDto> getList(PageInfo pi);

	public ContactDto getDetail(int boardNo);

	public int setDelete(int boardNo);

	public int answer(ContactDto contactDto);

}
