package kr.co.green.member.controller;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.mindrot.jbcrypt.BCrypt;

import kr.co.green.member.model.dto.Member;
import kr.co.green.member.model.service.MemberServiceImpl;

@WebServlet("/member/register.do")
public class RegisterController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public RegisterController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");

		String userName = request.getParameter("new-username");
		String userId = request.getParameter("new-userid");
		String userPwd = request.getParameter("new-password");
		String confirmPwd = request.getParameter("confirm-password");
		String duplicateCheck = request.getParameter("duplicateCheck");
//		System.out.println(duplicateCheck);

		if (duplicateCheck.equals("unavailable")) { // 중복되는 아이디가 있을 때
			response.sendRedirect("/form/registerForm.do");
			return;
		}

		// 유효성 검사
		// 이름 : 한글만 가능
		// 패스워드 : 영어 대문자 최소1개, 특수문자 최소 1개, 6이상 20이하
		// 이름 유효성 검사
		String namePattern = "^[가-힣]+$"; // 정규표현식 패턴 정의
		Pattern pattern = Pattern.compile(namePattern); // 패턴 객체 생성

		// 매체 객체 생성
		// 주어진 문자열이랑 정규표현식의 패턴이랑 일치하는지 비교하기 위해 필요한 객체
		Matcher nameMatcher = pattern.matcher(userName);

		// 패스워드 유혀성 검사
		String passwordPattern = "^(?=.*[A-Z])(?=.*[!@])[a-zA-z0-9!@]{6,20}$";
		Pattern pwdPattern = Pattern.compile(passwordPattern);
		Matcher pwdMatcher = pwdPattern.matcher(userPwd);

		String salt = BCrypt.gensalt(12);
		String hashPassword = BCrypt.hashpw(userPwd, salt);
//		System.out.println(userPwd);
//		System.out.println(salt);
//		System.out.println(hashPassword);
		
		if (nameMatcher.matches() && pwdMatcher.matches()) { // 정규표현식에 맞으면 true 틀리면 false
			Member member = new Member();
			member.setUserName(userName);
			member.setUserId(userId);
			member.setUserPwd(hashPassword);
			member.setConfirmPwd(confirmPwd);

			MemberServiceImpl memberService = new MemberServiceImpl();
			int result = memberService.register(member);

			if (result == 1) {
				RequestDispatcher view = request.getRequestDispatcher("/form/loginForm.do");
				view.forward(request, response);
			} else {
				RequestDispatcher view = request.getRequestDispatcher("/form/registerForm.do");
				view.forward(request, response);
			}

		}else if(!nameMatcher.matches()) { 		//이름이 한글이 아닐때
			returnAlert(response, "이름은 한글만 가능합니다");
		}else if(!pwdMatcher.matches()) {
			returnAlert(response, "패스워드는 영어 대문자 최소1개, 특수문자 최소 1개, 6자리 이상 20자리 이하만 가능합니다");
		}
		

	}
	private void returnAlert(HttpServletResponse response, String msg) throws IOException {
		response.getWriter().write("<script>"
				+ "alert('" + msg + "');"
				+ "location.href='/form/registerForm.do'"
				+ "</script>");
	}

}
