package kr.co.green.board.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import kr.co.green.board.model.dto.BoardDto;
import kr.co.green.board.model.dto.FreeDtoImpl;
import kr.co.green.common.DatabaseConnection;
import kr.co.green.common.PageInfo;

public class FreeDao {

	private Connection con;
	private DatabaseConnection dc;
	private PreparedStatement pstmt;

	public FreeDao() {
		dc = new DatabaseConnection();
		con = dc.connDB();

	}

	// 1. 쿼리 작성
//  MySQL offset 페이징
// String query = "SELECT fb_idx,"
//       + "            fb_title,"
//       + "            fb_in_date,"
//       + "            fb_views,"
//       + "            fb_writer"
//       + "      FROM free_board"
//       + "      LIMIT ? OFFSET ?";

//  MySQL cursor 페이징
// String query = "SELECT fb_idx,"
//       + "            fb_title,"
//       + "            fb_in_date,"
//       + "            fb_views,"
//       + "            fb_writer"
//       + "      FROM free_board"
//       + "      WHERE fb_idx > ? LIMIT ?";

// String query = "SELECT fb2.*"
//       + "      FROM (SELECT rownum AS rnum, fb.* "
//       + "           FROM (SELECT fb_idx,"
//    + "                         fb_title,"
//    + "                         fb_in_date,"
//    + "                          fb_views,"
//    + "                         fb_writer"
//    + "                    FROM free_board"
//    + "                    ORDER BY fb_in_date DESC) fb) fb2"
//    + "         WHERE rnum BETWEEN ? AND ?";
	public ArrayList<FreeDtoImpl> getList(PageInfo pi, String category, String searchText) {
		
		
		ArrayList<FreeDtoImpl> result = new ArrayList<>();
		String query = "SELECT * FROM FREE_BOARD fb " + "JOIN MEMBER m ON m.M_NO = fb.M_NO "
				+ "WHERE fb_delete_status = 'N' "
				+ "AND " + category + " LIKE '%' || ? || '%' "
				+ "ORDER BY fb_indate DESC " 
				+ "OFFSET ? ROWS FETCH FIRST ? ROWS ONLY";

		try {
			pstmt = con.prepareStatement(query);
			pstmt.setString(1, searchText);
			pstmt.setInt(2, pi.getOffset());
			pstmt.setInt(3, pi.getBoardLimit());

			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				int no = rs.getInt("FB_NO");
				String title = rs.getString("FB_TITLE");
				String content = rs.getString("FB_CONTENT");
				int views = rs.getInt("FB_VIEWS");
				String indate = rs.getString("FB_INDATE");
				int memberNo = rs.getInt("M_NO");
				String memberName = rs.getString("M_NAME");

				FreeDtoImpl freeDto = new FreeDtoImpl();
				freeDto.setBoardNo(no);
				freeDto.setBoardTitle(title);
				freeDto.setBoardContent(content);
				freeDto.setBoardViews(views);
				freeDto.setBoardIndate(indate);
				freeDto.setMemberNo(memberNo);
				freeDto.setMemberName(memberName);
				;

				result.add(freeDto);
			}
			pstmt.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	public int getListCount(String category, String searchText) {
		String query = "SELECT count(*) AS cnt "
				+ "FROM free_board fb " + " JOIN MEMBER m ON m.M_NO = fb.M_NO "
						+ "WHERE fb_delete_status = 'N'"
				+ "AND " + category + " LIKE '%' || ? || '%'" ;
		try {
			pstmt = con.prepareStatement(query);
			
			pstmt.setString(1, searchText);
			
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				int result = rs.getInt("CNT");
				System.out.println();
				return result;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return 0;
	}

	public int getEnroll(FreeDtoImpl bdto) {
		String qeury = "INSERT INTO free_board "
				+ "VALUES(free_board_seq.nextval,?,?,default, "
				+ "default,null,null, default,?)";
		int result = 0;

		try {
			pstmt = con.prepareStatement(qeury);
			pstmt.setString(1, bdto.getBoardTitle());
			pstmt.setString(2, bdto.getBoardContent());
			pstmt.setInt(3, bdto.getMemberNo());

			result = pstmt.executeUpdate();

			pstmt.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return result;
	}

	public FreeDtoImpl getDetail(int boardNo) {
		// 1. 쿼리 작성
		String query = "SELECT * FROM free_board "
				+ "WHERE FB_NO = ?";

		try {
			// 2. pstmt에 쿼리사용준비
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, boardNo);

			// 3. 쿼리 실행(반환값 resultSet)
			// 반환값이 int -> insert, delete, update
			// 반환값이 resultSet -> select
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				// 4. 튜플에 있는 컬럼의 값 꺼내기
				// 게시글번호, 제목, 내용, 작성자, 작성일, 조회수
				int fbNo = rs.getInt("FB_NO");
				String fbTitle = rs.getString("FB_TITLE");
				String fbContent = rs.getString("FB_CONTENT");
				String fbIndate = rs.getString("FB_INDATE");
				int fbViews = rs.getInt("FB_VIEWS");
				int mNo = rs.getInt("M_NO");

				FreeDtoImpl freeDto = new FreeDtoImpl();
				freeDto.setBoardNo(fbNo);
				freeDto.setBoardTitle(fbTitle);
				freeDto.setBoardContent(fbContent);
				freeDto.setBoardIndate(fbIndate);
				freeDto.setBoardViews(fbViews);
				freeDto.setMemberNo(mNo);

				return freeDto;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;

	}

	public void getWriter(FreeDtoImpl freeDto) {
		String query = "SELECT m_name FROM member "
				+ "WHERE m_no = ?";

		try {

			pstmt = con.prepareStatement(query);

			pstmt.setInt(1, freeDto.getMemberNo());

			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String mName = rs.getString("M_NAME");

				freeDto.setMemberName(mName);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public int setViews(int boardNo) {
		String query = "UPDATE free_board SET fb_views = fb_views + 1 "
				+ "WHERE fb_no = ?";

		try {
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, boardNo);

			int result = pstmt.executeUpdate();

			return result;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}

	public int setEdit(FreeDtoImpl freeDto) {
		// 1. String query 작성
		// title, content, update = sysdate
		String query = "UPDATE free_board SET fb_title = ?,"
				+ " fb_content = ?,"
				+ " fb_update = SYSDATE where fb_no = ?";
		// 2. 쿼리 사용준비
		try {
			pstmt = con.prepareStatement(query);
			
			// 3. 물음표 채워넣기
			pstmt.setString(1, freeDto.getBoardTitle());
			pstmt.setString(2, freeDto.getBoardContent());
			pstmt.setInt(3, freeDto.getBoardNo());
			// 4. 쿼리 실행
			int result = pstmt.executeUpdate();
			pstmt.close();
			con.close();
			
			return result;
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return 0;


		
	}
	
	public int setDelete(int boardNo) {
		String query = "UPDATE free_board SET"
				+ " fb_delete = SYSDATE,"
				+ " fb_delete_status = 'Y'"
				+ " WHERE fb_no = ?";
		
		try {
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, boardNo);
			
			int result = pstmt.executeUpdate();
			pstmt.close();
			con.close();
			
			return result;
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
	}

}
