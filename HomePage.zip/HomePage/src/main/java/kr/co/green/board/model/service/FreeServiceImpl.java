package kr.co.green.board.model.service;

import java.util.ArrayList;

import kr.co.green.board.model.dao.FreeDao;
import kr.co.green.board.model.dto.FreeDtoImpl;
import kr.co.green.common.PageInfo;

public class FreeServiceImpl implements BoardService{
	FreeDao freeDao;
	
	public FreeServiceImpl() {
		freeDao = new FreeDao();
	}
	

	@Override
	public ArrayList<FreeDtoImpl> getList(PageInfo pi, String category, String searchText){
		return freeDao.getList(pi,category,searchText);
	}
	
	@Override
	public int getListCount(String category, String searchText) {
		return freeDao.getListCount(category, searchText);
	}
	
	@Override
	public int enroll(FreeDtoImpl bdto) {
		return freeDao.getEnroll(bdto);
	}

	@Override
	public FreeDtoImpl getDetail(int boardNo) {
		//1. 작성자 조회
		FreeDtoImpl result = freeDao.getDetail(boardNo);
		//2. 조회수 증가
		freeDao.getWriter(result);
		//3. 조회수 1 증가
		int resultView = freeDao.setViews(result.getBoardNo());
		
		if(resultView ==1) {
			return result;
		}
		
		return null;
//		return freeDao.getDetail(boardNo);
	}

	@Override
	public FreeDtoImpl getEditForm(int boardNo) {
		FreeDtoImpl result = freeDao.getDetail(boardNo);
		
		freeDao.getWriter(result);
		
		return result;
	}
	@Override
	public int setEdit(FreeDtoImpl freeDto) {
		
		return freeDao.setEdit(freeDto);
	}
	
	
	@Override 
	public int setDelete(int boardNo) {
		return freeDao.setDelete(boardNo);
	}
}
