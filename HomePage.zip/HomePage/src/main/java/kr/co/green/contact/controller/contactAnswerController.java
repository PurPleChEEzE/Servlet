package kr.co.green.contact.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import kr.co.green.board.model.dto.FreeDtoImpl;
import kr.co.green.board.model.service.FreeServiceImpl;
import kr.co.green.contact.model.dto.ContactDto;
import kr.co.green.contact.model.service.ContactServiceImpl;

/**
 * Servlet implementation class contactAnswerController
 */
@WebServlet("/contact/answer.do")
public class contactAnswerController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public contactAnswerController() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int boardNo = Integer.parseInt(request.getParameter("boardNo"));
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		//boardNo로 게스길의 정보 불러오기
		ContactServiceImpl contactService = new ContactServiceImpl();
		ContactDto result = contactService.getDetail(boardNo);
		
		request.setAttribute("result", result);

		//필요한 정보 : 제목, 내용, 작성일, 조회수, 작성자
		
		//조회수 1 증가
		
		RequestDispatcher view = request.getRequestDispatcher("/views/contact/contactAnswer.jsp");
		view.forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
		int contentNumber = Integer.parseInt(request.getParameter("boardNo"));
//		System.out.println(contentNumber);
		String answerContent = request.getParameter("answer");
//		System.out.println(answerContent);
		
		HttpSession session = request.getSession();
		int memberNo = (int)session.getAttribute("userNo");
//		System.out.println(memberNo);
		
		ContactDto contactDto = new ContactDto(contentNumber, answerContent, memberNo);
		
		ContactServiceImpl contactService = new ContactServiceImpl();
		int result = contactService.answer(contactDto);
		
		if (result == 1) {
			RequestDispatcher view = request.getRequestDispatcher("/contact/list.do?cpage=1");
			view.forward(request, response);
		} 
	}
	
}
