package kr.co.green.contact.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import kr.co.green.common.DatabaseConnection;
import kr.co.green.contact.model.dto.ContactDto;
import kr.co.green.common.PageInfo;

public class ContactDao {
	private Connection con;
	private DatabaseConnection dc;
	private PreparedStatement pstmt;
	
	public ContactDao() {
		dc = new DatabaseConnection();
		con =dc.connDB();
		
		
	}

	public int enroll(ContactDto contactDto) {
		String query = "Insert INTO contact "
				+ "VALUES(contact_seq.nextval,?, ?, ?,"
				+ "default,default, ?)"; 
		int result = 0;
//		String?/String?/String?/Number?
		try {
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,contactDto.getName());
			pstmt.setString(2,contactDto.getMessage());
			pstmt.setString(3,contactDto.getEmail());
			pstmt.setInt(4,contactDto.getMemberNo());
			
			result = pstmt.executeUpdate();
			
			pstmt.close();
			con.close();
	
		}catch(SQLException e){
			e.printStackTrace();
		}
		
		return result;		
	}

	public int getListCount() {
		String query = "SELECT COUNT(*) AS cnt FROM contact";
		
		try {
			pstmt = con.prepareStatement(query);
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				int result = rs.getInt("CNT");
				return result;
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	
	public ArrayList<ContactDto> getList(PageInfo pi){
		ArrayList<ContactDto> result = new ArrayList<>();
		String query = "SELECT * FROM contact ct " + "JOIN MEMBER m ON m.M_NO = ct.M_NO "
								+ "ORDER BY c_indate DESC " + "OFFSET ? ROWS FETCH FIRST ? ROWS ONLY";
		
		try {
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, pi.getOffset());
			pstmt.setInt(2, pi.getBoardLimit());
			
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				//번호, 이름, 이메일, 작성일, 답변
				int no = rs.getInt("C_NO");
				String name = rs.getString("C_NAME");
				String email = rs.getString("C_EMAIL");
				String indate = rs.getString("C_INDATE");
				String message = rs.getString("C_MESSAGE");
				String answerStatus = rs.getString("C_ANSWER_STATUS");
				int memberNo = rs.getInt("M_NO");
				ContactDto contactDto = new ContactDto(no, name, email, indate, message, answerStatus, memberNo);
				
				result.add(contactDto);
			}
			
			pstmt.close();
			con.close();
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return result;
	}

	public ContactDto getDetail(int boardNo) {
		String query = "SELECT * FROM contact c LEFT JOIN contact_answer ca ON c.c_no = ca.c_no WHERE c.c_no = ?";
		
		try {
			pstmt = con.prepareStatement(query);
			pstmt.setInt(1, boardNo);
			
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				// 게시글넘버,작성자,이메일,작성일,작성내용
				int cNo = rs.getInt("C_NO");
				String cName = rs.getString("C_NAME");
				String cEmail = rs.getString("C_EMAIL");
				String cMessage = rs.getString("C_MESSAGE");
				String cIndate = rs.getString("C_INDATE");
				int mNo = rs.getInt("M_NO");
				
				String cAnswer = rs.getString("CA_CONTENT");
				String cAnswerIndate = rs.getString("CA_INDATE");
				int caNo = rs.getInt("CA_NO");
				String cAnswerStatus = rs.getString("C_ANSWER_STATUS");
				
				ContactDto contactDto = new ContactDto(cAnswerStatus, cAnswer, cAnswerIndate, caNo, cNo, cName, cEmail, cMessage, cIndate, mNo);
				return contactDto;
				
			}
		}catch(SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public int setDelete(int boardNo) {
		String query1 = "DELETE FROM contact_answer WHERE c_no = ?";
		String query2 = "DELETE FROM contact WHERE c_no = ?";
		
		int result = 0;
		try {
			pstmt = con.prepareStatement(query1);
			pstmt.setInt(1, boardNo);
			
			pstmt.executeUpdate();
			pstmt.close();
			
			pstmt = con.prepareStatement(query2);
			pstmt.setInt(1, boardNo);
			
			result = pstmt.executeUpdate();
			
			pstmt.close();
			con.close();
//			System.out.println(result);
		}catch(SQLException e) {
			e.printStackTrace();
		}
		
		return result;
	}

	public int answer(ContactDto contactDto) {
		int result = 0;
		String query = "INSERT INTO contact_answer ca "
				+ " VALUES(contact_answer_seq.nextval, ?, default, ?, ?)";
		
		String query2 = "UPDATE contact SET c_answer_status = 'Y' WHERE c_no = ?";
		
//		String?/number?/number?
		try {
			pstmt = con.prepareStatement(query);
			pstmt.setString(1,contactDto.getAnswerContent());
			pstmt.setInt(2,contactDto.getMemberNo());
			pstmt.setInt(3,contactDto.getNo());
			pstmt.executeUpdate();
			pstmt.close();
			
			
			pstmt = con.prepareStatement(query2);
			pstmt.setInt(1, contactDto.getNo());
			
			result = pstmt.executeUpdate();
			
			pstmt.close();
			con.close();
//			System.out.println(contactDto.getAnswerContent());
//			System.out.println(contactDto.getMemberNo());
//			System.out.println(contactDto.getNo());
		}catch(SQLException e){
			e.printStackTrace();
		}
		
		return result;
	}
	

	
}
