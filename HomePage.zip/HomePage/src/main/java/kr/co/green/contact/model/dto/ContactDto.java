package kr.co.green.contact.model.dto;

public class ContactDto {
	// 문의번호 = no
	// 문의 내용 = message
	// 문의 작성자 = name
	// 문의 이메일 = email
	// 문의 작성일 = indate
	// 답변 여부 = answerStatus (Y/N)
	// 답변 번호 = answerNo
	// 답변 내용 = answerContent
	// 답변 작성자 = answerWriter
	// 답변 작성일 = answerIndate
	private int no;
	private String message;
	private String name;
	private String email;
	private String indate;

	private String answerStatus;
	private int answerNo;
	private int memberNo;
	private String answerContent;
	private String answerWriter;
	private String answerIndate;

	public int getMemberNo() {
		return memberNo;
	}

	public void setMemberNo(int memberNo) {
		this.memberNo = memberNo;
	}

	public ContactDto() {
		super();
	}

	public ContactDto(String name, String email, String message, int memberNo) {
		super();
		this.name = name;
		this.email = email;
		this.message = message;
		this.memberNo = memberNo;
	}

	public ContactDto(int no, String name, String email, String indate, String message, String answerStatus,
			int memberNo) {
		super();
		this.no= no;
		this.name = name;
		this.email = email;
		this.indate = indate;
		this.message = message;
		this.answerStatus = answerStatus;
		this.memberNo = memberNo;
	}

	public ContactDto(int cNo, String cName, String cEmail, String cMessage, String cIndate, int mNo) {
		super();
		this.no = cNo;
		this.name = cName;
		this.email = cEmail;
		this.message = cMessage;
		this.indate = cIndate;
		this.memberNo = mNo;
		
	}



	public ContactDto(int contentNumber, String answerContent, int memberNo) {
		super();
		this.no = contentNumber;
		this.answerContent = answerContent;
		this.memberNo = memberNo;
	}

	public ContactDto(String cAnswerStatus , String cAnswer, String cAnswerIndate, int caNo, int cNo, String cName, String cEmail,
			String cMessage, String cIndate, int mNo) {
		super();
		this.answerStatus = cAnswerStatus;
		this.answerIndate = cAnswerIndate;
		this.answerContent = cAnswer;
		this.answerNo = caNo;
		
		this.no = cNo;
		this.name = cName;
		this.email = cEmail;
		this.message = cMessage;
		this.indate = cIndate;
		this.memberNo = mNo;
		
		
	}

	

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getIndate() {
		return indate;
	}

	public void setIndate(String indate) {
		this.indate = indate;
	}

	public String getAnswerStatus() {
		return answerStatus;
	}

	public void setAnswerStatus(String answerStatus) {
		this.answerStatus = answerStatus;
	}

	public int getAnswerNo() {
		return answerNo;
	}

	public void setAnswerNo(int answerNo) {
		this.answerNo = answerNo;
	}

	public String getAnswerContent() {
		return answerContent;
	}

	public void setAnswerContent(String answerContent) {
		this.answerContent = answerContent;
	}

	public String getAnswerWriter() {
		return answerWriter;
	}

	public void setAnswerWriter(String answerWriter) {
		this.answerWriter = answerWriter;
	}

	public String getAnswerIndate() {
		return answerIndate;
	}

	public void setAnswerIndate(String answerIndate) {
		this.answerIndate = answerIndate;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
